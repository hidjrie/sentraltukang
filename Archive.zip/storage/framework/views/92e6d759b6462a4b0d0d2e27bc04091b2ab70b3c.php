<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<div class="w-full max-w-xs bg-white shadow shadow-md m-auto mt-4">
    <img src="img/avatar-placeholder.png" alt="" class="w-full mb-5">
    <div class="p-5"><?php echo e($profile->name); ?></div>
    <div class="pl-5"><?php echo e($profile->email); ?></div>
    <div class="p-5">
        <a type="submit" href="" class="w-full rounded-md p-2 text-main-orange shadow shadow-md border border-grey-400 text-center hover:bg-main-green hover:text-white"><i class="fas fa-cog"></i> Edit Profile</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sentraltukang/resources/views/profile.blade.php ENDPATH**/ ?>