<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1 class="text-center mt-3 mb-2 text-2xl text-main-orange uppercase">Edit Profile</h1>
<div class="w-full max-w-xs bg-white shadow shadow-md m-auto mt-4 mb-4">
    <img src="<?php echo e(asset('img/avatar-placeholder.png')); ?>" alt="" class="w-full mb-5">

    <form role="form" action="<?php echo e(route('profile.update', $profile->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PATCH')); ?>


        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="mb-3 px-5">
            <input type="text" name="name" id="name" placeholder="Name"
                class="border-b-2 border-main-green w-full p-2 outline-none focus:border-main-orange"
                value="<?php echo e($profile->name); ?>">
        </div>
        <div class="mb-5 px-5">
            <input type="password" name="password" id="password" placeholder="New Password"
                class="border-b-2 border-main-green w-full p-2 outline-none focus:border-main-orange">
        </div>
        <div class="mb-3 px-5">
            <input type="password" name="password_confirmation" id="password-confirm" placeholder="New Confirm Password"
                class="border-b-2 border-main-green w-full p-2 outline-none focus:border-main-orange">
        </div>
        <div class="px-5">
            <button type="submit" href=""
                class="w-full rounded-md p-2 mb-2 text-white shadow text-center bg-main-orange hover:bg-secondary-orange shadow shadow-md focus:outline-none"><i
                    class="fas fa-check"></i> Save Profile</button>
        </div>
        <div class="px-5">
            <a type="submit" href="<?php echo e(route('profile.index')); ?>"
                class="w-full mb-4 rounded-md p-2 text-white shadow shadow-md border text-center bg-main-green hover:bg-secondary-green">Back</a>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sentraltukang/resources/views/profile/edit.blade.php ENDPATH**/ ?>