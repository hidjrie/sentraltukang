<?php if(count($errors) > 0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p class="bg-main-orange mb-5 p-2 text-white">
    <i class="fas fa-exclamation-triangle"></i> <?php echo e($error); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php if(session()->has('message')): ?>
<div class="w-100 bg-main-green p-2 m-0 text-white"><?php echo e(session('message')); ?></div>
<?php endif; ?><?php /**PATH /Applications/MAMP/htdocs/sentraltukang/resources/views/includes/messages.blade.php ENDPATH**/ ?>