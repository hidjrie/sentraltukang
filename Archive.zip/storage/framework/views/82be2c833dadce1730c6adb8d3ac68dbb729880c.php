<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="text-center mt-3 mb-2 text-2xl text-main-orange uppercase">Your Profile</h1>
<div class="w-full max-w-xs bg-white shadow shadow-md m-auto my-4">
    <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <img src="<?php echo e(asset('img/avatar-placeholder.png')); ?>" alt="avatar" class="w-full mb-3">
    <div class="px-5">
        <h3 class="text-main-orange text-lg md:text-md font-semibold"><?php echo e($profile->name); ?></h3>
    </div>
    <div class="px-5 pt-3 text-gray-700"><i class="far fa-envelope"></i> <?php echo e($profile->email); ?></div>
    <div class="px-5 pt-3 text-gray-700"> <i class="far fa-clock"></i>
        Registered since <?php echo e(\Carbon\Carbon::parse($profile->created_at)->isoFormat('d MMMM Y')); ?></div>
    <div class="p-5">
        <a type="submit" href="<?php echo e(route('profile.edit', $profile)); ?>"
            class="w-full rounded-md p-2 text-main-green shadow shadow-md border border-grey-400 text-center hover:bg-main-green hover:text-white"><i
                class="fas fa-cog"></i> Edit Profile</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/sentraltukang/resources/views/profile/profile.blade.php ENDPATH**/ ?>