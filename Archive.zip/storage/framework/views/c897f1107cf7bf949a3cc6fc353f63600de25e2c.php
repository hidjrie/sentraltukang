<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>sentraltukang by Ikhsannul Hijri</title>

    
    <meta name="description" content="sentraltukang demo app created by Ikhsannul Hijri">
    <meta name="keywords" content="sentraltukang, unico, toko bangunan">
    <meta name="author" content="Ikhsannul Hijri">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>

<body>
    <div class="landing-page-container w-screen h-screen m-0 p-0 flex flex-col items-center justify-center">
        <div>
            <img src="<?php echo e(asset('img/sentraltukang-logo.png')); ?>" alt="">
        </div>
        <div>
            <h1 class="text-main-orange  text-2xl sm:text-2xl md:text-3xl lg:text-4xl font-semibold text-center">This is
                demo app created by <strong>Ikhsannul Hijri</strong></h1>
        </div>
        <div class="flex flex-col sm:flex-row mt-5">
            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(url('users')); ?>">
                <div
                    class="sm:ml-8 mt-4 sm:mt-0 border border-main-orange px-6 py-2 rounded-full bg-main-orange text-white text-xl text-center hover:bg-secondary-orange hover:text-white">
                    User List
                </div>
            </a>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>">
                <div
                    class="sm:ml-8 mt-4 sm:mt-0 border border-main-orange px-6 py-2 rounded-full bg-main-orange text-white text-xl text-center hover:bg-secondary-orange hover:text-white">
                    Login
                </div>
            </a>
            <?php if(Route::has('register')): ?>
            <a href="<?php echo e(route('register')); ?>">
                <div
                    class="sm:ml-8 mt-4 sm:mt-0 border border-main-green px-6 py-2 rounded-full bg-main-green text-white text-xl text-center hover:bg-secondary-green hover:text-white">
                    Register
                </div>
            </a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</body>

</html><?php /**PATH /Applications/MAMP/htdocs/sentraltukang/resources/views/welcome.blade.php ENDPATH**/ ?>