@extends('layouts.app')

@section('content')

@include('layouts.navbar')
<user-list></user-list>

@endsection