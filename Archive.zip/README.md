<p align="center"><img src="https://github.com/hidjrie/sentraltukang/blob/master/public/img/sentraltukang-logo.png?raw=true" width="400"></p>

## About This App

This app is only for demo purpose created by Ikhsannul Hijri

## Frameworks and Libraries
* Lannguage: PHP
* Backend Framework: Laravel
* Frontend Framework: Vue.js
* CSS Framework: Tailwind CSS
* Other Library: Font Awesome

## Link Repository

https://github.com/hidjrie/sentraltukang

 
